const Discord = require("discord.js")
const { client, config } = require("../index.js")

client.on("ready", () => {

    console.log("|\n|    Advanced MassDM\n|  Made By ᗪᕼᖇᑌᐯツ†ᶜˣ#8276\n|\n| Last Update: 18.10.2020\n|")

    client.user.setActivity(`DM  |ᗪᕼᖇᑌᐯツ†ᵇᵗᵒ ᵀᴳ#8276 to add me to ur server `, { type: "PLAYING" }).catch(console.error);

})